package com.test.cucumber.Utilities;

import com.test.cucumber.Base.DriverHelpers;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class WebElementsHelper {
    private WebElement element;
    private DriverHelpers dHelpers;
    private WebDriver driver;

    public WebElementsHelper(WebDriver driver)
    {
        this.driver = driver;
    }
    public void findElementbyContainsTextAndClick(String text) {
        element = driver.findElement(By.xpath("//*[contains(text(),'" + text + "')]"));
        if (element.getText().equals(text))
            element.click();
        else throw new NoSuchElementException("Element not found");
    }

}
