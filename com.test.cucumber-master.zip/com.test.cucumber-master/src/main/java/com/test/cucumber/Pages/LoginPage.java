package com.test.cucumber.Pages;

import com.test.cucumber.Base.DriverHelpers;
import com.test.cucumber.Utilities.WaitHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.openqa.selenium.support.FindBy;


public class LoginPage {

    WebDriver driver;

    //----------------Constructoer to initialize the WelElement---//
    public LoginPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }
    WaitHelper wt = new WaitHelper();

    @FindBy(id="username")
    private WebElement userName;
    public void enterUserName(String uname){
        wt.setExplicitWaitElement(driver, userName);
        userName.sendKeys(uname);
    }

    @FindBy(id="pwd")
    private WebElement password;
    public void enterPassword(String pwds){
        wt.setExplicitWaitElement(driver,password);
        password.sendKeys(pwds);
    }

    @FindBy(id="LgButton")
    private WebElement LoginButton;
    public void clickOnLoginBtn(){
        wt.setExplicitWaitElement(driver,LoginButton);
        LoginButton.click();
    }

    public void verifyLoginPageTitle(){
        Assert.assertEquals(driver.getTitle(), "title");
    }

}
