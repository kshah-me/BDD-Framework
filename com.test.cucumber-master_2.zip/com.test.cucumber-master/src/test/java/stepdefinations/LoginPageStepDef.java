package stepdefinations;

import com.test.cucumber.Base.DriverHelpers;
import com.test.cucumber.Pages.LoginPage;
import com.test.cucumber.Utilities.PropertyReader;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class LoginPageStepDef {

    LoginPage loginPage = new LoginPage(DriverHelpers.getDriver());

    @Given("user is on login page")
    public void userIsOnLoginPage() {
        System.out.println("Here is me");
        DriverHelpers.getDriver().get(PropertyReader.propValueFromConfigFile("url"));
    }

    @When("user enter the username {string}")
    public void userEntersValidUserName(String unm)
    {
        loginPage.enterUserName(unm);
    }

    @And("user enter the password {string}")
    public void userEntersValidPassword(String pd)
    {
        loginPage.enterPassword(pd);
    }

    @Then("user click on login Button")
    public void userClickOnLoginButton()
    {
        loginPage.clickOnLoginBtn();
    }

}
