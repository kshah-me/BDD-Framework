package Hooks;


import com.test.cucumber.Base.DriverHelpers;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.openqa.selenium.WebDriver;


public class Hooks {
    public static WebDriver driver;
    @Before()
    public void intDriver(){
       driver = DriverHelpers.initDriver();

    }

    @After()
    public void closeDriver()
    {
        driver.quit();

    }

}
