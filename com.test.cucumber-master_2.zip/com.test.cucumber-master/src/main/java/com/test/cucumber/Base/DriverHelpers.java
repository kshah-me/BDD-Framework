package com.test.cucumber.Base;

import com.test.cucumber.Utilities.PropertyReader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;

import java.time.Duration;

public class DriverHelpers {
    private static WebDriver driver;

    public static WebDriver initDriver() {

        switch (PropertyReader.propValueFromConfigFile("BrowserName").toLowerCase()) {
            case "chrome" -> {
                ChromeOptions options = new ChromeOptions();
                if (Boolean.parseBoolean(PropertyReader.propValueFromConfigFile("headlessMode"))) {
                    options.addArguments("--headless=new");
                }
                driver = new ChromeDriver(options);
            }

            case "firefox" -> {
                FirefoxOptions options = new FirefoxOptions();
                if (Boolean.parseBoolean(PropertyReader.propValueFromConfigFile("headlessMode"))) {
                    options.addArguments("--headless=new");
                }
                driver = new FirefoxDriver(options);
            }

            case "edge" -> {
                EdgeOptions options = new EdgeOptions();
                if (Boolean.parseBoolean(PropertyReader.propValueFromConfigFile("headlessMode"))) {
                    options.addArguments("--headless=new");
                }
                driver = new EdgeDriver(options);
            }

            case "safari" -> {
                if (Boolean.parseBoolean(PropertyReader.propValueFromConfigFile("headlessMode"))) {
                    System.out.println("⚠️ Headless mode is not supported for Safari. Launching in GUI mode.");
                }
                SafariOptions options = new SafariOptions();
                driver = new SafariDriver(options);
            }

            default -> throw new IllegalArgumentException("❌ Browser type not supported: " + PropertyReader.propValueFromConfigFile("BrowserName"));
        }

        getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
        getDriver().manage().deleteAllCookies();
        getDriver().manage().window().maximize();
        System.out.println("Browser launched: " + PropertyReader.propValueFromConfigFile("BrowserName") + " | Headless: " + Boolean.parseBoolean(PropertyReader.propValueFromConfigFile("headlessMode")));
        return getDriver();
    }

    public static WebDriver getDriver() {
        return driver;
    }

}
