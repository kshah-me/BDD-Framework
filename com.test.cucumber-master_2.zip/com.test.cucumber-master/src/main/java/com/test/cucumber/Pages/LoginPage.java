package com.test.cucumber.Pages;

import com.test.cucumber.Base.DriverHelpers;
import com.test.cucumber.Utilities.WaitHelper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.openqa.selenium.support.FindBy;


public class LoginPage{

    WebDriver driver;
    WaitHelper wt = new WaitHelper();
    //----------------Constructoer to initialize the WelElement---//
    public LoginPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver,this);
    }



    @FindBy(id="login")
    private WebElement userName;
    public void enterUserName(String uname){
        wt.setExplicitWaitElement(userName);
        userName.sendKeys(uname);
    }

    @FindBy(id="password")
    private WebElement password;
    public void enterPassword(String pwds){
        wt.setExplicitWaitElement(password);
        password.sendKeys(pwds);
    }

    @FindBy(xpath="//span[text()='Log in']/parent::button")
    private WebElement LoginButton;
    public void clickOnLoginBtn(){
        wt.setExplicitWaitElement(LoginButton);
        LoginButton.click();
    }

    public void verifyLoginPageTitle(){
        Assert.assertEquals(driver.getTitle(), "title");
    }

}
