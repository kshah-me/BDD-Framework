package com.test.cucumber.Utilities;


import com.test.cucumber.Base.DriverHelpers;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;


public class WaitHelper extends  DriverHelpers{

    WebDriver driver;
    public WaitHelper() {

        driver = WaitHelper.getDriver();
    }

    public void setExplicitWaitElement(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
        wait.until(ExpectedConditions.visibilityOf(element));
    }

    public void setExplicitWaitElementClickInterceptedException(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(50));
        wait.until(ExpectedConditions.elementToBeClickable(element));

    }

    public void waitForPageLoad(WebDriver driver){
        new WebDriverWait(driver, Duration.ofSeconds(50)).until(webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
    }
    public void setFluenttWaitElement(WebElement element){
        Wait<WebDriver> wait =
                new FluentWait<>(driver)
                        .withTimeout(Duration.ofSeconds(50))
                        .pollingEvery(Duration.ofSeconds(5))
                        .ignoring(ElementNotInteractableException.class);

        wait.until(
                d -> {
                    element.sendKeys("Displayed");
                    return true;
                });

    }
}
